import java.util.ArrayList;
import java.util.List;

public class Campeonato {
    private String nomeCampeonato;
    private String dataInicio;
    private String dataFim;
    private List<Equipa> equipasParticipantes;
    private List<Partida> partidas; // Adicione esta linha

    // Construtor
    public Campeonato(String nomeCampeonato, String dataInicio, String dataFim) {
        this.nomeCampeonato = nomeCampeonato;
        this.dataInicio = dataInicio;
        this.dataFim = dataFim;
        this.equipasParticipantes = new ArrayList<>();
        this.partidas = new ArrayList<>(); // Inicialize a lista de partidas
    }

    // Métodos para adicionar e remover equipas participantes
    public void adicionarEquipa(Equipa equipa) {
        equipasParticipantes.add(equipa);
    }

    public void removerEquipa(Equipa equipa) {
        equipasParticipantes.remove(equipa);
    }

    // Métodos para adicionar e obter a lista de partidas
    public void adicionarPartida(Partida partida) {
        partidas.add(partida);
    }

    public List<Partida> getPartidas() {
        return partidas;
    }

    // Métodos para obter informações sobre o campeonato
    public String getNomeCampeonato() {
        return nomeCampeonato;
    }

    public String getDataInicio() {
        return dataInicio;
    }

    public String getDataFim() {
        return dataFim;
    }

    public List<Equipa> getEquipasParticipantes() {
        return equipasParticipantes;
    }

    public  void listarEquipas(){
        int count = 0;
        for (Partida partida : partidas){
            count++;
            System.out.println("Partida "  + count);
            for(Equipa equipa : partida.getEquipas()){
                System.out.println("Time : " + equipa.getNomeEquipa() +  " Resultado : " + equipa.getPontos());
            }
            System.out.println();
        }
    }
}
