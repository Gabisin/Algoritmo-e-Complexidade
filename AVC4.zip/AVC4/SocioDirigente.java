public class SocioDirigente extends Socio {
    private int anosMandato;

    // Construtor
    public SocioDirigente(String nome, int numeroSocio, String numBilheteIdentidade, String numContribuinte,
                          String morada, String numeroTelefone, String email, String dataInscricao, int anosMandato) {
        super(nome, numeroSocio, numBilheteIdentidade, numContribuinte, morada, numeroTelefone, email, dataInscricao);
        this.anosMandato = anosMandato;
    }

    // Getter e setter para anos de mandato
    public int getAnosMandato() {
        return anosMandato;
    }

    public void setAnosMandato(int anosMandato) {
        this.anosMandato = anosMandato;
    }

    // Método para adicionar anos de mandato
    public void adicionarAnosMandato(int anos) {
        this.anosMandato += anos;
    }
}
