import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;
public class Associado {
    private String nome;
    private  int numeroSocio;
    private  String numBilheteIdentidade;
    private  String numContribuinte;
    private  String morada;
    private   String numeroTelefone;
    private   String email;
    private  String estatuto;
    private  String dataInscricao;
    private List<AtividadeDesportiva> atividadesInscritas = new ArrayList<>();
    private List<Associado>  associados = new ArrayList<>();

    private boolean quotasPagas = false;
    private List<Integer> anosQuotasPendentes = new ArrayList<>();
    // Construtor
    public Associado(String nome, int numeroSocio, String numBilheteIdentidade, String numContribuinte,
                     String morada, String numeroTelefone, String email, String estatuto, String dataInscricao) {
        this.nome = nome;
        this.numeroSocio = numeroSocio;
        this.numBilheteIdentidade = numBilheteIdentidade;
        this.numContribuinte = numContribuinte;
        this.morada = morada;
        this.numeroTelefone = numeroTelefone;
        this.email = email;
        this.estatuto = estatuto;
        this.dataInscricao = dataInscricao;

    }


    // Getters e setters para cada atributo omitidos para brevidade

    // Método para verificar se as quotas estão em dia
    public void adicionarAssociado(Associado associado) {
        associados.add(associado);
    }
    public void removerJogador(Associado associado) {
        associados.remove(associado);
    }
    public boolean verificarQuotasEmDia() {
        // Obter o ano atual
        int anoAtual = LocalDate.now().getYear();

        // Obter o ano de inscrição
        int anoInscricao = LocalDate.parse(dataInscricao).getYear();

        // Verificar se as quotas estão em dia
        return anoAtual == anoInscricao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getNumeroSocio() {
        return numeroSocio;
    }

    public void setNumeroSocio(int numeroSocio) {
        this.numeroSocio = numeroSocio;
    }

    public String getNumContribuinte() {
        return numContribuinte;
    }

    public void setNumContribuinte(String numContribuinte) {
        this.numContribuinte = numContribuinte;
    }

    public String getNumBilheteIdentidade() {
        return numBilheteIdentidade;
    }

    public void setNumBilheteIdentidade(String numBilheteIdentidade) {
        this.numBilheteIdentidade = numBilheteIdentidade;
    }

    public String getMorada() {
        return morada;
    }

    public void setMorada(String morada) {
        this.morada = morada;
    }

    public String getNumeroTelefone() {
        return numeroTelefone;
    }

    public void setNumeroTelefone(String numeroTelefone) {
        this.numeroTelefone = numeroTelefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEstatuto() {
        return estatuto;
    }

    public void setEstatuto(String estatuto) {
        this.estatuto = estatuto;
    }

    public  void listarAssociados(){
        for (Associado associado : associados){
            System.out.println("Nome do Associado : " + associado.nome);
        }
    }

}

