public class Socio {
    private String nome;
    private int numeroSocio;
    private String numBilheteIdentidade;
    private String numContribuinte;
    private String morada;
    private String numeroTelefone;
    private String email;
    private String dataInscricao;

    // Construtor
    public Socio(String nome, int numeroSocio, String numBilheteIdentidade, String numContribuinte,
                 String morada, String numeroTelefone, String email, String dataInscricao) {
        this.nome = nome;
        this.numeroSocio = numeroSocio;
        this.numBilheteIdentidade = numBilheteIdentidade;
        this.numContribuinte = numContribuinte;
        this.morada = morada;
        this.numeroTelefone = numeroTelefone;
        this.email = email;
        this.dataInscricao = dataInscricao;
    }

    // Getters e setters para cada atributo

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getNumeroSocio() {
        return numeroSocio;
    }

    public void setNumeroSocio(int numeroSocio) {
        this.numeroSocio = numeroSocio;
    }

    public String getNumBilheteIdentidade() {
        return numBilheteIdentidade;
    }

    public void setNumBilheteIdentidade(String numBilheteIdentidade) {
        this.numBilheteIdentidade = numBilheteIdentidade;
    }

    public String getNumContribuinte() {
        return numContribuinte;
    }

    public void setNumContribuinte(String numContribuinte) {
        this.numContribuinte = numContribuinte;
    }

    public String getMorada() {
        return morada;
    }

    public void setMorada(String morada) {
        this.morada = morada;
    }

    public String getNumeroTelefone() {
        return numeroTelefone;
    }

    public void setNumeroTelefone(String numeroTelefone) {
        this.numeroTelefone = numeroTelefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDataInscricao() {
        return dataInscricao;
    }

    public void setDataInscricao(String dataInscricao) {
        this.dataInscricao = dataInscricao;
    }
}
