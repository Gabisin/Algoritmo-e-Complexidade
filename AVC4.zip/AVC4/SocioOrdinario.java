public class SocioOrdinario extends Socio {
    // Construtor
    public SocioOrdinario(String nome, int numeroSocio, String numBilheteIdentidade, String numContribuinte,
                           String morada, String numeroTelefone, String email, String dataInscricao) {
        super(nome, numeroSocio, numBilheteIdentidade, numContribuinte, morada, numeroTelefone, email, dataInscricao);
    }
}
