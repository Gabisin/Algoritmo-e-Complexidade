import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;

public class CampeonatoManager {
    private List<Campeonato> campeonatos;

    public CampeonatoManager() {
        this.campeonatos = new ArrayList<>();
    }

    public void adicionarCampeonato(Campeonato campeonato) {
        campeonatos.add(campeonato);
    }

    public void adicionarPartida(Campeonato campeonato, Partida partida) {
        campeonato .adicionarPartida(partida);
    }

    public void calcularPontuacao(Campeonato campeonato) {
        List<Partida> partidas = campeonato.getPartidas();

        for (Partida partida : partidas) {
            List<Equipa> equipas = partida.getEquipas();
            Equipa equipe1 = equipas.get(0);
            Equipa equipe2 = equipas.get(1);

            int pontuacaoEquipe1 = partida.getPontuacaoEquipa(equipe1);
            int pontuacaoEquipe2 = partida.getPontuacaoEquipa(equipe2);

            if (pontuacaoEquipe1 > pontuacaoEquipe2) {
                // Equipe 1 venceu
                equipe1.adicionarPontos(3);
            } else if (pontuacaoEquipe1 < pontuacaoEquipe2) {
                // Equipe 2 venceu
                equipe2.adicionarPontos(3);
            } else {
                // Empate
                equipe1.adicionarPontos(1);
                equipe2.adicionarPontos(1);
            }
        }
    }

    public void gerarClassificacao(Campeonato campeonato) {
        List<Equipa> equipas = campeonato.getEquipasParticipantes();

        // Ordena as equipas com base nos pontos acumulados
        Collections.sort(equipas, new Comparator<Equipa>() {
            @Override
            public int compare(Equipa equipe1, Equipa equipe2) {
                return Integer.compare(equipe2.getPontos(), equipe1.getPontos());
            }
        });

        // Imprime a classificação das equipas
        System.out.println("Classificação do campeonato:");
        for (int i = 0; i < equipas.size(); i++) {
            Equipa equipe = equipas.get(i);
            System.out.println((i + 1) + ". " + equipe.getNomeEquipa() + " - Pontos: " + equipe.getPontos());
        }
    }
}
