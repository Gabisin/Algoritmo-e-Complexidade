import java.util.ArrayList;
import java.util.List;

public class Teste {
    public static void main(String[] args) {
        // Criar alguns associados
        Associado associado1 = new Associado("João", 1, "12345", "67890", "Rua A", "123456789", "joao@email.com", "01/01/2022", "tipo1");
        Associado associado2 = new Associado("Maria", 2, "54321", "09876", "Rua B", "987654321", "maria@email.com", "02/01/2022", "tipo2");
        associado1.adicionarAssociado(associado1);
        associado1.adicionarAssociado(associado2);

        associado1.listarAssociados();
        // Criar algumas atividades desportivas
        AtividadeDesportiva futsal = new AtividadeDesportiva("Futsal", "Ginásio A", associado1);
        AtividadeDesportiva paintball = new AtividadeDesportiva("Paintball", "Campo B", associado2);

        // Criar algumas equipas
        Equipa equipa1 = new Equipa("Equipa 1", "Mascote 1");
        Equipa equipa2 = new Equipa("Equipa 2", "Mascote 2");

        // Criar algumas partidas
        List<Equipa> equipasPartida1 = new ArrayList<>();
        equipasPartida1.add(equipa1);
        equipasPartida1.add(equipa2);

        Partida partida1 = new Partida(equipasPartida1);

        List<Equipa> equipasPartida2 = new ArrayList<>();
        equipasPartida2.add(equipa1);
        equipasPartida2.add(equipa2);
        Partida partida2 = new Partida(equipasPartida2);

        partida1.setNumero(1);
        partida1.setData("10/03/2024");

        partida2.setNumero(2);
        partida2.setData("15/03/2024");

        // Adicionar as partidas às equipas
        equipa1.adicionarPartida(partida1);
        equipa2.adicionarPartida(partida1);
        equipa1.adicionarPartida(partida2);
        equipa2.adicionarPartida(partida2);

        // Definir resultados das partidas
        partida1.definirResultado(equipa1, 3);
        partida1.definirResultado(equipa2, 2);
        partida2.definirResultado(equipa1, 1);
        partida2.definirResultado(equipa2, 1);

        // Criar um campeonato
        Campeonato campeonato = new Campeonato("Campeonato de Futsal", "01/03/2024", "30/03/2024");

        // Adicionar as partidas ao campeonato
        campeonato.adicionarPartida(partida1);
        campeonato.adicionarPartida(partida2);

        // Criar um CampeonatoManager e calcular a pontuação e gerar a classificação
        CampeonatoManager campeonatoManager = new CampeonatoManager();
        campeonatoManager.calcularPontuacao(campeonato);
        campeonatoManager.gerarClassificacao(campeonato);

        campeonato.listarEquipas();
    }
}
