public class AtividadeDesportiva {
    private String nomeAtividade;
    private String localizacao;
    private Associado responsavel;



    // Construtor
    public AtividadeDesportiva(String nomeAtividade, String localizacao, Associado responsavel) {
        this.nomeAtividade = nomeAtividade;
        this.localizacao = localizacao;
        this.responsavel = responsavel;
    }

    // Getters and setters
    public String getNomeAtividade() {
        return nomeAtividade;
    }

    public void setNomeAtividade(String nomeAtividade) {
        this.nomeAtividade = nomeAtividade;
    }

    public String getLocalizacao() {
        return localizacao;
    }

    public void setLocalizacao(String localizacao) {
        this.localizacao = localizacao;
    }

    public Associado getResponsavel() {
        return responsavel;
    }
    public void setResponsavel(Associado responsavel) {
        this.responsavel = responsavel;
    }
}
