public class Espaco {
    private String identificacao;
    private Associado responsavel;

    // Construtor
    public Espaco(String identificacao, Associado responsavel) {
        this.identificacao = identificacao;
        this.responsavel = responsavel;
    }

    // Getters e setters para cada atributo

    public String getIdentificacao() {
        return identificacao;
    }

    public void setIdentificacao(String identificacao) {
        this.identificacao = identificacao;
    }

    public Associado getResponsavel() {
        return responsavel;
    }

    public void setResponsavel(Associado responsavel) {
        this.responsavel = responsavel;
    }
}
