import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class Partida {
    private final List<Equipa> equipas;
    private final Map<Equipa, Integer> resultado;
    private int numero; // Adicionando o atributo número
    private String data; // Adicionando o atributo data

    public Partida(List<Equipa> equipas) {
        this.equipas = equipas;
        this.resultado = new HashMap<>();
    }

    public void definirResultado(Equipa equipa, int pontuacao) {
        resultado.put(equipa, pontuacao);
    }

    public int getPontuacaoEquipa(Equipa equipa) {
        return resultado.getOrDefault(equipa, 0);
    }

    public List<Equipa> getEquipas() {
        return equipas;
    }
    // Método para definir o número da partida
    public void setNumero(int numero) {
        this.numero = numero;
    }

    // Método para definir a data da partida
    public void setData(String data) {
        this.data = data;
    }
}
