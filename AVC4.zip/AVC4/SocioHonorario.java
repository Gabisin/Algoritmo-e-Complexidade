public class SocioHonorario extends Socio {
    // Construtor
    public SocioHonorario(String nome, int numeroSocio, String numBilheteIdentidade, String numContribuinte,
                           String morada, String numeroTelefone, String email, String dataInscricao) {
        super(nome, numeroSocio, numBilheteIdentidade, numContribuinte, morada, numeroTelefone, email, dataInscricao);
    }
}
