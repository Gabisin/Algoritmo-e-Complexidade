import java.util.ArrayList;
import java.util.List;

public class Equipa {
    private String nomeEquipa;
    private String mascote;
    private List<Associado>  associados = new ArrayList<>();
    private int pontos = 0; // Initialize pontos directly at declaration
    private List<Partida> partidas = new ArrayList<>();
    // Construtor
    public Equipa(String nomeEquipa, String mascote) {
        this.nomeEquipa = nomeEquipa;
        this.mascote = mascote;

    }

    // Métodos para adicionar e remover Associado da equipa
    public void adicionarJogador(Associado jogador) {
        associados.add(jogador);
    }

    public void removerJogador(Associado jogador) {
        associados.remove(jogador);
    }

    // Métodos para obter informações sobre a equipa
    public String getNomeEquipa() {
        return nomeEquipa;
    }

    public String getMascote() {
        return mascote;
    }

    public void setMascote(String mascote) {
        this.mascote = mascote;
    }

    public List<Associado> getAssociado() {
        return associados;
    }

    public int getPontos() {
        return pontos;
    }

    public void adicionarPontos(int pontos) {
        this.pontos += pontos;
    }
    public void adicionarPartida(Partida partida) {

            partidas.add(partida);

    }
    public void removerPartida(Partida partida) {
        partidas.remove(partida);

    }

}
